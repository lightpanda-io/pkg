# Copyright 2017 The Chromium Authors. All rights reserved.
# Use of this source code is governed by a BSD-style license that can be
# found in the LICENSE file.


DEPS = [
  'recipe_engine/cipd',
  'recipe_engine/context',
  'recipe_engine/platform',
  'recipe_engine/runtime',
]

from .api import DepotToolsApi as API
