# Copyright 2018 The Chromium Authors
# Use of this source code is governed by a BSD-style license that can be
# found in the LICENSE file.

import sys

import config_util


class InspectorProtocol(config_util.Config):
    @staticmethod
    def fetch_spec(props):
        url = "https://chromium.googlesource.com/deps/inspector_protocol.git"
        solution = {
            "name": "src",
            "url": url,
            "custom_deps": {},
        }
        spec = {
            "solutions": [solution],
        }
        return {
            "type": "gclient_git",
            "gclient_git_spec": spec,
        }

    @staticmethod
    def expected_root(_props):
        return "src"


def main(argv=None):
    return InspectorProtocol().handle_args(argv)


if __name__ == "__main__":
    sys.exit(main(sys.argv))
