# Copyright 2013 The Chromium Authors
# Use of this source code is governed by a BSD-style license that can be
# found in the LICENSE file.

import sys

import config_util


class AndroidInternal(config_util.Config):
    """Basic Config alias for AndroidInternal -> Chromium."""

    @staticmethod
    def fetch_spec(props):
        return {
            "alias": {
                "config": "chromium",
                "props": ["--target_os=android", "--internal=True"],
            },
        }

    @staticmethod
    def expected_root(_props):
        return ""


def main(argv=None):
    return AndroidInternal().handle_args(argv)


if __name__ == "__main__":
    sys.exit(main(sys.argv))
