# Copyright 2016 The Chromium Authors
# Use of this source code is governed by a BSD-style license that can be
# found in the LICENSE file.


DEPS = ["presubmit", "recipe_engine/json"]


def RunSteps(api):
  api.presubmit()


def GenTests(api):
  yield (api.test("basic") + api.step_data("presubmit", api.json.output({})))
