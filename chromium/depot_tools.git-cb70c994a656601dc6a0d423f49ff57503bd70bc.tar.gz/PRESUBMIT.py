# Copyright 2012 The Chromium Authors
# Use of this source code is governed by a BSD-style license that can be
# found in the LICENSE file.
"""Top-level presubmit script for depot tools.

See http://dev.chromium.org/developers/how-tos/depottools/presubmit-scripts for
details on the presubmit API built into depot_tools.
"""

PRESUBMIT_VERSION = "2.0.0"

import fnmatch  # noqa: E402
import sys  # noqa: E402

# CIPD ensure manifest for checking CIPD client itself.
CIPD_CLIENT_ENSURE_FILE_TEMPLATE = r"""
# Full supported.
$VerifiedPlatform linux-amd64 mac-amd64 windows-amd64 windows-386
# Best effort support.
$VerifiedPlatform linux-386 linux-ppc64 linux-ppc64le linux-s390x
$VerifiedPlatform linux-arm64 linux-armv6l
$VerifiedPlatform linux-mips64 linux-mips64le linux-mipsle

%s %s
"""

# Timeout for a test to be executed.
TEST_TIMEOUT_S = 450  # 7m 30s


def CheckRuff(input_api, output_api):
    """Run ruff check on python files."""
    return input_api.RunTests(
        input_api.canned_checks.GetRuff(
            input_api,
            output_api,
            files_to_skip=_GetRuffFilesToSkip(input_api),
        )
    )


def _GetRuffFilesToSkip(input_api):
    files_to_skip = list(input_api.DEFAULT_FILES_TO_SKIP)
    if input_api.os_path.exists(".gitignore"):
        with open(".gitignore", encoding="utf-8") as fh:
            lines = [line.strip() for line in fh.readlines()]
            files_to_skip.extend(
                [
                    fnmatch.translate(line)
                    for line in lines
                    if line and not line.startswith("#")
                ]
            )
    if input_api.os_path.exists(".git/info/exclude"):
        with open(".git/info/exclude", encoding="utf-8") as fh:
            lines = [line.strip() for line in fh.readlines()]
            files_to_skip.extend(
                [
                    fnmatch.translate(line)
                    for line in lines
                    if line and not line.startswith("#")
                ]
            )
    return files_to_skip


def CheckRecipes(input_api, output_api):
    file_filter = lambda x: x.LocalPath() == "infra/config/recipes.cfg"  # noqa: E731
    return input_api.canned_checks.CheckJsonParses(
        input_api, output_api, file_filter=file_filter
    )


def CheckUsePython3(input_api, output_api):
    results = []

    if sys.version_info.major != 3:
        results.append(
            output_api.PresubmitError(
                "Did not use Python3 for //tests/PRESUBMIT.py."
            )
        )

    return results


def CheckJsonFiles(input_api, output_api):
    return input_api.canned_checks.CheckJsonParses(input_api, output_api)


def CheckUnitTestsOnCommit(input_api, output_api):
    """Do not run integration tests on upload since they are way too slow."""

    input_api.SetTimeout(TEST_TIMEOUT_S)

    # Run only selected tests on Windows.
    test_to_run_list = [r".*test\.py$"]
    tests_to_skip_list = []
    if input_api.platform.startswith(("cygwin", "win32")):
        print("Warning: skipping most unit tests on Windows")
        tests_to_skip_list.extend(
            [
                r".*auth_test\.py$",
                r".*git_common_test\.py$",
                r".*git_hyper_blame_test\.py$",
                r".*git_map_test\.py$",
                r".*ninjalog_uploader_test\.py$",
                r".*recipes_test\.py$",
                r".*run_in_virtual_path_test\.py$",
            ]
        )

    tests = input_api.canned_checks.GetUnitTestsInDirectory(
        input_api,
        output_api,
        "tests",
        files_to_check=test_to_run_list,
        files_to_skip=tests_to_skip_list,
    )

    return input_api.RunTests(tests)


def CheckCIPDManifest(input_api, output_api):
    # Validate CIPD manifests.
    root = input_api.os_path.normpath(
        input_api.os_path.abspath(input_api.PresubmitLocalPath())
    )
    rel_file = lambda rel: input_api.os_path.join(root, rel)  # noqa: E731
    cipd_manifests = set(
        rel_file(input_api.os_path.join(*x))
        for x in (
            ("cipd_manifest.txt",),
            ("bootstrap", "manifest.txt"),
            ("bootstrap", "manifest_bleeding_edge.txt"),
            # Also generate a file for the cipd client itself.
            ("cipd_client_version",),
        )
    )
    affected_manifests = input_api.AffectedFiles(
        include_deletes=False,
        file_filter=lambda x: (
            input_api.os_path.normpath(x.AbsoluteLocalPath()) in cipd_manifests
        ),
    )
    tests = []
    for path in affected_manifests:
        path = path.AbsoluteLocalPath()
        if path.endswith(".txt"):
            tests.append(
                input_api.canned_checks.CheckCIPDManifest(
                    input_api, output_api, path=path
                )
            )
        else:
            pkg = "infra/tools/cipd/${platform}"
            ver = input_api.ReadFile(path)
            tests.append(
                input_api.canned_checks.CheckCIPDManifest(
                    input_api,
                    output_api,
                    content=CIPD_CLIENT_ENSURE_FILE_TEMPLATE % (pkg, ver),
                )
            )
            tests.append(
                input_api.canned_checks.CheckCIPDClientDigests(
                    input_api, output_api, client_version_file=path
                )
            )

    return input_api.RunTests(tests)


def CheckOwnersFormat(input_api, output_api):
    return input_api.canned_checks.CheckOwnersFormat(input_api, output_api)


def CheckOwnersOnUpload(input_api, output_api):
    return input_api.canned_checks.CheckOwners(
        input_api, output_api, allow_tbr=False
    )


def CheckDoNotSubmitOnCommit(input_api, output_api):
    return input_api.canned_checks.CheckDoNotSubmit(input_api, output_api)


def CheckPatchFormatted(input_api, output_api):
    # TODO(https://crbug.com/979330) If clang-format is fixed for non-chromium
    # repos, remove check_clang_format=False so that proto files can be
    # formatted
    return input_api.canned_checks.CheckPatchFormatted(
        input_api, output_api, check_clang_format=False
    )


def CheckFreezeOnCommit(input_api, output_api):
    return input_api.canned_checks.CheckInfraFreeze(input_api, output_api)


def CheckAyeAye(input_api, output_api):
    return input_api.canned_checks.CheckAyeAye(input_api, output_api)


def CheckSkillFiles(input_api, output_api):
    """Validates SKILL.md files have correct frontmatter and formatting."""
    return input_api.canned_checks.CheckSkillFiles(input_api, output_api)


def CheckSkillValidatorTestsOnCommit(input_api, output_api):
    """Runs skill-validator tests on commit."""
    tests = input_api.canned_checks.GetUnitTestsInDirectory(
        input_api,
        output_api,
        input_api.os_path.join(
            "agents", "skills", "skill-validator", "scripts"
        ),
        files_to_check=[r".*test\.py$"],
    )
    return input_api.RunTests(tests)


def CheckVPythonSpec(input_api, output_api):
    """Validates that modified vpython specs match their companion uv.lock files."""
    return input_api.RunTests(
        input_api.canned_checks.CheckVPythonSpec(input_api, output_api)
    )
